/* eslint-disable no-underscore-dangle */
import { runScriptlet, clearGlobalProps } from '../helpers';

const { test, module } = QUnit;
const name = 'prevent-addEventListener';

const nativeDescriptor = Object.getOwnPropertyDescriptor(window.EventTarget.prototype, 'addEventListener');

const beforeEach = () => {
    window.__debug = () => {
        window.hit = 'FIRED';
    };
};

const afterEach = () => {
    clearGlobalProps('__debug', 'hit');
    Object.defineProperty(window.EventTarget.prototype, 'addEventListener', nativeDescriptor);
    Object.defineProperty(window, 'addEventListener', nativeDescriptor);
    Object.defineProperty(document, 'addEventListener', nativeDescriptor);
};

module(name, { beforeEach, afterEach });

test('Checking if alias name works', (assert) => {
    const adgParams = {
        name,
        engine: 'test',
        verbose: true,
    };
    const aliasParams = {
        name: 'ubo-addEventListener-defuser.js',
        engine: 'test',
        verbose: true,
    };

    const codeByAdgParams = window.scriptlets.invoke(adgParams);
    const codeByAliasParams = window.scriptlets.invoke(aliasParams);

    assert.strictEqual(codeByAdgParams, codeByAliasParams);
});

test('should not prevent addEventListener if listener is null', (assert) => {
    const TEST_EVENT_NAME = 'testPassive';
    const TEST_CALLBACK_MATCH = 'clicked';
    runScriptlet(name, [TEST_EVENT_NAME, TEST_CALLBACK_MATCH]);

    const element = document.createElement('div');
    element.addEventListener(TEST_EVENT_NAME, null);
    element.click();

    assert.strictEqual(window.hit, undefined, 'hit should not be fired');
});

test('should not prevent addEventListener if listener is invalid object', (assert) => {
    const TEST_EVENT_NAME = 'testPassive';
    const TEST_CALLBACK_MATCH = 'clicked';
    runScriptlet(name, [TEST_EVENT_NAME, TEST_CALLBACK_MATCH]);

    const element = document.createElement('div');
    const invalidListener = Object.create(null);
    element.addEventListener(TEST_EVENT_NAME, invalidListener);
    element.click();

    assert.strictEqual(window.hit, undefined, 'hit should not be fired');
});

test('should not prevent addEventListener if event is undefined', (assert) => {
    const TEST_EVENT_NAME = window.undefinedEvent; // not defined
    const TEST_CALLBACK_MATCH = 'clicked';

    runScriptlet(name, [TEST_EVENT_NAME, TEST_CALLBACK_MATCH]);

    const testProp = 'test';
    window[testProp] = 'start';
    const element = document.createElement('div');
    element.addEventListener(TEST_EVENT_NAME, () => {
        window[testProp] = 'final';
    });

    assert.strictEqual(window.hit, undefined, 'hit should not be fired');
    assert.strictEqual(window[testProp], 'start', 'property should not be changed');
    clearGlobalProps(testProp);
});

test('should not throw error when event type is null', (assert) => {
    const TEST_EVENT_NAME = 'testEvent';
    runScriptlet(name, [TEST_EVENT_NAME]);

    const testProp = 'test';
    window[testProp] = 'start';

    // This should not throw an error
    assert.expect(2);
    try {
        document.addEventListener(null, () => {});
        window[testProp] = 'end';
    } catch (e) {
        assert.ok(false, `Should not throw error: ${e.message}`);
    }

    assert.strictEqual(window[testProp], 'end', 'property should be changed to end');
    assert.strictEqual(window.hit, undefined, 'hit should not be fired');
    clearGlobalProps(testProp);
});

test('does not allow to add event listener', (assert) => {
    const scriptletArgs = ['click', 'clicked'];
    runScriptlet(name, scriptletArgs);

    const testProp = 'testProp';
    const element = document.createElement('div');
    element.addEventListener('click', () => {
        window[testProp] = 'clicked';
    });
    element.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testProp], undefined, 'property should be undefined');
    clearGlobalProps(testProp);
});

test('event listeners not corresponding to scriptlet arguments should be added correctly', (assert) => {
    const scriptletArgs = ['click', undefined];
    runScriptlet(name, scriptletArgs);

    const focusProp = 'focusProp';
    const element = document.createElement('div');
    element.addEventListener('focus', () => {
        window[focusProp] = 'focused';
    });

    element.dispatchEvent(new Event('focus'));
    assert.strictEqual(window.hit, undefined, 'hit function not fired');
    assert.strictEqual(window[focusProp], 'focused', 'property should change');

    const clickProp = 'clickProp';
    element.addEventListener('click', () => {
        window[clickProp] = 'clicked';
    });
    element.click();
    assert.strictEqual(window.hit, 'FIRED', 'hit function should fire');
    assert.strictEqual(window[clickProp], undefined, 'property should be undefined');
    clearGlobalProps(clickProp, focusProp);
});

test('event listeners with handlers matched with regexp not added', (assert) => {
    const scriptletArgs = [undefined, '/click/'];
    runScriptlet(name, scriptletArgs);

    const element = document.createElement('div');

    const clickProp = 'clickProp';
    element.addEventListener('click', () => {
        window[clickProp] = 'clicked'; // this string matches with regex
    });
    element.click();
    assert.strictEqual(window.hit, 'FIRED', 'hit function should not fire');
    assert.strictEqual(window[clickProp], undefined, 'property should be undefined');
    clearGlobalProps('hit');

    const focusProp = 'focusProp';
    element.addEventListener('focus', () => {
        window[focusProp] = 'clicked'; // this string matches with regex
    });
    element.dispatchEvent(new Event('focus'));
    assert.strictEqual(window.hit, 'FIRED', 'hit function not fired');
    assert.strictEqual(window[focusProp], undefined, 'property should be undefined');
    clearGlobalProps('hit');

    // this event listener should work correctly
    element.addEventListener('click', () => {
        window[focusProp] = 'focus'; // this string doesn't match with regex
    });
    element.click();
    assert.strictEqual(window.hit, undefined, 'hit function should not fire');
    assert.strictEqual(window[focusProp], 'focus', 'property should change');

    clearGlobalProps(clickProp, focusProp);
});

test('event listeners should be added correctly -- invalid event regexp pattern', (assert) => {
    const scriptletArgs = ['/*/', undefined];
    runScriptlet(name, scriptletArgs, false);

    const focusProp = 'focusProp';
    const element = document.createElement('div');
    element.addEventListener('focus', () => {
        window[focusProp] = 'focused';
    });

    element.dispatchEvent(new Event('focus'));
    assert.strictEqual(window.hit, undefined, 'hit function not fired');
    assert.strictEqual(window[focusProp], 'focused', 'property should change');
});

test('event listeners should be added correctly -- invalid func regexp pattern', (assert) => {
    const scriptletArgs = ['focus', '/\\/'];
    runScriptlet(name, scriptletArgs, false);

    const focusProp = 'focusProp';
    const element = document.createElement('div');
    element.addEventListener('focus', () => {
        window[focusProp] = 'focused';
    });

    element.dispatchEvent(new Event('focus'));
    assert.strictEqual(window.hit, undefined, 'hit function not fired');
    assert.strictEqual(window[focusProp], 'focused', 'property should change');
});

test('match simple single quote mark', (assert) => {
    const scriptletArgs = ['click', 'single\'quote'];
    runScriptlet(name, scriptletArgs);

    const testProp = 'testProp';
    const element = document.createElement('div');
    element.addEventListener('click', () => {
        window[testProp] = "single'quote";
    });
    element.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testProp], undefined, 'property should be undefined');
    clearGlobalProps(testProp);
});

test('match single quote mark with one backslash before it', (assert) => {
    // eslint-disable-next-line no-useless-escape
    const scriptletArgs = ['click', "single\'quote"];
    runScriptlet(name, scriptletArgs);

    const testProp = 'testProp';
    const element = document.createElement('div');
    element.addEventListener('click', () => {
        window[testProp] = "single'quote";
    });
    element.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testProp], undefined, 'property should be undefined');
    clearGlobalProps(testProp);
});

test('match escaped quote mark', (assert) => {
    const scriptletArgs = ['click', "\\'quote"];
    runScriptlet(name, scriptletArgs);

    const testProp = 'testProp';
    const element = document.createElement('div');
    element.addEventListener('click', () => {
        window[testProp] = "escaped\\'quote";
    });
    element.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testProp], undefined, 'property should be undefined');
    clearGlobalProps(testProp);
});

test('match element with class name', (assert) => {
    const scriptletArgs = ['click', 'clicked', 'elements', '.match'];
    runScriptlet(name, scriptletArgs);

    const testPropMatch = 'testPropMatch';
    const elementMatches = document.createElement('div');
    elementMatches.className = 'match';
    elementMatches.addEventListener('click', () => {
        window[testPropMatch] = 'clicked';
    });
    elementMatches.click();

    const testPropDoesNotMatch = 'testPropDoesNotMatch';
    const elementDoesNotMatch = document.createElement('div');
    elementDoesNotMatch.className = 'doesNotMatch';
    elementDoesNotMatch.addEventListener('click', () => {
        window[testPropDoesNotMatch] = 'clicked';
    });
    elementDoesNotMatch.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testPropMatch], undefined, 'property should be undefined');
    assert.strictEqual(window[testPropDoesNotMatch], 'clicked', 'property should be clicked');

    clearGlobalProps(testPropMatch, testPropDoesNotMatch);
});

test('match window', (assert) => {
    const scriptletArgs = ['click', 'clicked', 'elements', 'window'];
    runScriptlet(name, scriptletArgs);

    const testPropMatch = 'testPropMatch';
    window.addEventListener('click', () => {
        window[testPropMatch] = 'clicked';
    });
    const event = new Event('click');
    window.dispatchEvent(event);

    const testPropDoesNotMatch = 'testPropDoesNotMatch';
    document.addEventListener('click', () => {
        window[testPropDoesNotMatch] = 'clicked';
    });
    const eventDoesNotMatch = new Event('click');
    document.dispatchEvent(eventDoesNotMatch);

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testPropMatch], undefined, 'property should be undefined');
    assert.strictEqual(window[testPropDoesNotMatch], 'clicked', 'property should be clicked');

    clearGlobalProps(testPropMatch, testPropDoesNotMatch);
});

test('match document', (assert) => {
    const scriptletArgs = ['click', 'clicked', 'elements', 'document'];
    runScriptlet(name, scriptletArgs);

    const testPropMatch = 'testPropMatch';
    document.addEventListener('click', () => {
        window[testPropMatch] = 'clicked';
    });
    const event = new Event('click');
    document.dispatchEvent(event);

    const testPropDoesNotMatch1 = 'testPropDoesNotMatch1';
    window.addEventListener('click', () => {
        window[testPropDoesNotMatch1] = 'clicked1';
    });
    const eventDoesNotMatch = new Event('click');
    window.dispatchEvent(eventDoesNotMatch);

    const testPropDoesNotMatch2 = 'testPropDoesNotMatch2';
    const elementDoesNotMatch = document.createElement('div');
    elementDoesNotMatch.className = 'doesNotMatch';
    elementDoesNotMatch.addEventListener('click', () => {
        window[testPropDoesNotMatch2] = 'clicked2';
    });
    elementDoesNotMatch.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testPropMatch], undefined, 'property should be undefined');
    assert.strictEqual(window[testPropDoesNotMatch1], 'clicked1', 'property should be clicked1');
    assert.strictEqual(window[testPropDoesNotMatch2], 'clicked2', 'property should be clicked2');

    clearGlobalProps(testPropMatch, testPropDoesNotMatch1, testPropDoesNotMatch2);
});

test('noProtect parameter allows subsequent override of addEventListener', (assert) => {
    const scriptletArgs = ['click', 'clicked', '', '', 'true'];
    runScriptlet(name, scriptletArgs);

    // Verify the scriptlet works on element
    const testProp = 'testProp';
    const element = document.createElement('div');
    element.addEventListener('click', () => {
        window[testProp] = 'clicked';
    });
    element.click();

    assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
    assert.strictEqual(window[testProp], undefined, 'property should be undefined');
    clearGlobalProps('hit');

    // Verify window.addEventListener works without recursion/stack overflow
    const windowTestProp = 'windowTestProp';
    window.addEventListener('customEvent', () => {
        window[windowTestProp] = 'windowListenerCalled';
    });
    window.dispatchEvent(new Event('customEvent'));
    assert.strictEqual(window[windowTestProp], 'windowListenerCalled', 'window.addEventListener should work');
    clearGlobalProps(windowTestProp);

    // Verify document.addEventListener works without recursion/stack overflow
    const docTestProp = 'docTestProp';
    document.addEventListener('customDocEvent', () => {
        window[docTestProp] = 'docListenerCalled';
    });
    document.dispatchEvent(new Event('customDocEvent'));
    assert.strictEqual(window[docTestProp], 'docListenerCalled', 'document.addEventListener should work');
    clearGlobalProps(docTestProp);

    // Now verify that addEventListener can be overridden
    let overrideWorked = false;
    window.EventTarget.prototype.addEventListener = function customWrapper() {
        overrideWorked = true;
    };

    const element2 = document.createElement('div');
    element2.addEventListener('click', () => {});

    assert.strictEqual(overrideWorked, true, 'addEventListener should be overridable with noProtect');
    clearGlobalProps(testProp);
});

test('default behavior (no noProtect) protects addEventListener from override', (assert) => {
    const scriptletArgs = ['click', 'clicked'];
    runScriptlet(name, scriptletArgs);

    // Verify descriptor has protective setter and getter
    const descriptor = Object.getOwnPropertyDescriptor(
        window.EventTarget.prototype,
        'addEventListener',
    );

    assert.strictEqual(typeof descriptor.get, 'function', 'descriptor should have a getter');
    assert.strictEqual(typeof descriptor.set, 'function', 'descriptor should have a setter');
    assert.strictEqual(descriptor.configurable, true, 'descriptor should be configurable');

    const originalWrapper = descriptor.get();

    // Try to override addEventListener - should be silently ignored due to no-op setter
    window.EventTarget.prototype.addEventListener = function maliciousWrapper() {
        throw new Error('This should not be called');
    };

    // The getter should still return the scriptlet's wrapper, not the malicious one
    const currentAddEventListener = window.EventTarget.prototype.addEventListener;
    assert.strictEqual(
        currentAddEventListener,
        originalWrapper,
        'addEventListener should still be the scriptlet wrapper after attempted override',
    );

    // Verify the setter is effectively a no-op by checking the getter still returns original
    assert.strictEqual(
        descriptor.get(),
        originalWrapper,
        'getter should still return original wrapper after setter was called',
    );
});
