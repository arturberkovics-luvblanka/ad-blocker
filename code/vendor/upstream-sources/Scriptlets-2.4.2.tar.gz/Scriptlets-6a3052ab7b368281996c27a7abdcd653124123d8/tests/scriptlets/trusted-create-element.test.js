/* eslint-disable no-underscore-dangle, no-console */
import { runScriptlet, clearGlobalProps } from '../helpers';

const { test, module } = QUnit;
const name = 'trusted-create-element';

const IFRAME_WINDOW_NAME = 'trusted-create-element-window';

const ROOT_ID = 'root-id';
const ROOT_SELECTOR = `#${ROOT_ID}`;

const createRoot = (id) => {
    const root = document.createElement('div');
    root.id = id;
    document.body.append(root);
    return root;
};

const removeRoot = () => {
    const root = document.querySelector(ROOT_SELECTOR);
    root?.remove();
};

const beforeEach = () => {
    window.__debug = () => {
        window.hit = 'FIRED';
    };
};

const afterEach = () => {
    removeRoot();
    clearGlobalProps('hit', '__debug');
};

module(name, { beforeEach, afterEach });

test('creating empty div', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'div';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, '', 'Text content is set correctly');
    assert.strictEqual(child.attributes.length, 0, 'No attributes were set');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('creating two elements', async (assert) => {
    const childTagName1 = 'div';
    const childTagName2 = 'span';

    runScriptlet(name, [ROOT_SELECTOR, childTagName1]);
    runScriptlet(name, [ROOT_SELECTOR, childTagName2]);

    const { children } = createRoot(ROOT_ID);

    assert.strictEqual(children.length, 0, 'Parent element has no children yet');

    const done = assert.async();

    // Wait for elements to be added
    setTimeout(() => {
        assert.strictEqual(children.length, 2, 'Only specified children were appended');

        const child1 = children[0];
        const child2 = children[1];

        assert.strictEqual(child1.tagName.toLowerCase(), childTagName1, 'Tag name is set correctly');
        assert.strictEqual(child1.textContent, '', 'Text content is set correctly');
        assert.strictEqual(child1.attributes.length, 0, 'No attributes were set');

        assert.strictEqual(child2.tagName.toLowerCase(), childTagName2, 'Tag name is set correctly');
        assert.strictEqual(child2.textContent, '', 'Text content is set correctly');
        assert.strictEqual(child2.attributes.length, 0, 'No attributes were set');

        assert.strictEqual(window.hit, 'FIRED', 'hit fired');

        done();
    }, 10);
});

test('creating two elements - one inside another', async (assert) => {
    const childTagName1 = 'div';
    const childTagName2 = 'div';
    const child2ClassName = 'adsbygoogle';

    runScriptlet(name, [ROOT_SELECTOR, childTagName1]);
    runScriptlet(name, [`${ROOT_SELECTOR} > ${childTagName1}`, childTagName2, `class="${child2ClassName}"`]);

    const { children } = createRoot(ROOT_ID);

    assert.strictEqual(children.length, 0, 'Parent element has no children yet');

    const done = assert.async();

    // Wait for elements to be added
    setTimeout(() => {
        assert.strictEqual(children.length, 1, 'Only specified children were appended');

        const child1 = children[0];
        const child2 = child1.querySelector('div.adsbygoogle');

        assert.strictEqual(child1.tagName.toLowerCase(), childTagName1, 'Tag name is set correctly');
        assert.strictEqual(child1.textContent, '', 'Text content is set correctly');
        assert.strictEqual(child1.attributes.length, 0, 'No attributes were set');

        assert.strictEqual(child2.tagName.toLowerCase(), childTagName2, 'Tag name is set correctly');
        assert.strictEqual(child2.textContent, '', 'Text content is set correctly');
        assert.strictEqual(child2.classList.contains('adsbygoogle'), true, '"adsbygoogle" class is set correctly');

        assert.strictEqual(window.hit, 'FIRED', 'hit fired');

        done();
    }, 10);
});

test('setting text content', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'DIV';
    const textContent = 'this is text content of an element';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, '', textContent]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName.toLowerCase(), 'Tag name is set correctly');
    assert.strictEqual(child.textContent, textContent, 'Text content is set correctly');
    assert.strictEqual(child.attributes.length, 0, 'No attributes were set');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('setting single attribute', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'img';
    const attributeName = 'src';
    const attributeValue = './test-files/test-image.jpeg';
    const attributesParam = `${attributeName}="${attributeValue}"`;

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, attributesParam]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, '', 'Text content is set correctly');

    assert.strictEqual(child.getAttribute(attributeName), attributeValue, 'Attribute is set correctly');
    assert.strictEqual(child.getAttributeNames().length, 1, 'Specified amount of attributes were set');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('multiple attributes with space in value', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'div';
    const attributeName1 = 'class';
    const attributeValue1 = 'adsbygoogle adsbygoogle-noablate';
    const attributeName2 = 'data-adsbygoogle-status';
    const attributeValue2 = 'done';
    const attributeName3 = 'data-ad-status';
    const attributeValue3 = 'filled';
    // eslint-disable-next-line max-len
    const attributesParam = `${attributeName1}="${attributeValue1}" ${attributeName2}="${attributeValue2}" ${attributeName3}="${attributeValue3}"`;
    const textContent = 'this is text content of an element';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, attributesParam, textContent]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, textContent, 'Text content is set correctly');

    assert.strictEqual(child.getAttribute(attributeName1), attributeValue1, 'Attribute 1 is set correctly');
    assert.strictEqual(child.getAttribute(attributeName2), attributeValue2, 'Attribute 2 is set correctly');
    assert.strictEqual(child.getAttribute(attributeName3), attributeValue3, 'Attribute 3 is set correctly');
    assert.strictEqual(child.getAttributeNames().length, 3, 'Specified amount of attributes were set');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('multiple attributes + attribute with no value', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'p';
    const attributeName1 = 'aria-hidden';
    const attributeValue1 = 'true';
    const attributeName2 = 'style';
    const attributeValue2 = 'width:0px';
    const attributeWithoutValue = 'attr3';
    // eslint-disable-next-line max-len
    const attributesParam = `${attributeName1}="${attributeValue1}" ${attributeName2}="${attributeValue2}" ${attributeWithoutValue}`;
    const textContent = 'this is text content of an element';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, attributesParam, textContent]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, textContent, 'Text content is set correctly');

    assert.strictEqual(child.getAttribute(attributeName1), attributeValue1, 'Attribute 1 is set correctly');
    assert.strictEqual(child.getAttribute(attributeName2), attributeValue2, 'Attribute 2 is set correctly');
    assert.strictEqual(child.getAttribute(attributeWithoutValue), '', 'Attribute 3 is set correctly');
    assert.strictEqual(child.getAttributeNames().length, 3, 'Specified amount of attributes were set');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('element cleanup by timeout', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'DIV';
    const cleanupDelayMs = 50;

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, '', '', cleanupDelayMs]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName, childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, '', 'Text content is set correctly');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');

    const done = assert.async();
    setTimeout(() => {
        assert.strictEqual(children.length, 0, 'Child element was removed after timeout');
        done();
    }, cleanupDelayMs + 10);
});

test('element cleanup by timeout, check if element was not added again', (assert) => {
    // If element is re-added in a loop, then it will stuck on this test

    const childTagName = 'SPAN';
    const cleanupDelayMs = 100;

    runScriptlet(name, [ROOT_SELECTOR, childTagName, '', '', cleanupDelayMs]);

    const done = assert.async();

    let child;
    let children;
    const rootElement = createRoot(ROOT_ID);

    setTimeout(() => {
        children = rootElement.children;
        // eslint-disable-next-line prefer-destructuring
        child = children[0];
        assert.strictEqual(window.hit, 'FIRED', 'hit fired');
        assert.strictEqual(children.length, 1, 'Only specified child was appended');
        assert.strictEqual(child.tagName, childTagName, 'Tag name is set correctly');
    }, cleanupDelayMs / 2);

    setTimeout(() => {
        assert.strictEqual(children.length, 0, 'Child element was removed after timeout');
        done();
    }, cleanupDelayMs + 10);
});

test('running scriptlet before root element is created', (assert) => {
    const childTagName = 'div';

    runScriptlet(name, [ROOT_SELECTOR, childTagName]);

    const { children } = createRoot(ROOT_ID);

    const done = assert.async();
    setTimeout(() => {
        assert.strictEqual(children.length, 1, 'Only specified child was appended');

        const child = children[0];

        assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
        assert.strictEqual(child.textContent, '', 'Text content is set correctly');

        assert.strictEqual(window.hit, 'FIRED', 'hit fired');
        done();
    }, 10);
});

test('creating iframe', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'IFRAME';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName]);

    assert.strictEqual(children.length, 1, 'Only specified child was appended');

    const child = children[0];

    assert.strictEqual(child.tagName, childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, '', 'Text content is set correctly');
    assert.strictEqual(child.contentWindow.name, IFRAME_WINDOW_NAME, 'window.name is set correctly');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');
});

test('creating script element with textContent', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'script';
    const textContent = 'window.scriptTestVar = "trusted-create-element-script";';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, '', textContent]);

    assert.strictEqual(children.length, 1, 'Script element was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.textContent, textContent, 'Text content is set correctly');
    assert.strictEqual(window.scriptTestVar, 'trusted-create-element-script', 'Script was executed');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');

    clearGlobalProps('scriptTestVar');
});

test('creating script element with attributes', (assert) => {
    const { children } = createRoot(ROOT_ID);

    const childTagName = 'script';
    const attributesParam = 'type="text/javascript" data-test="value"';
    const textContent = 'window.scriptTestVar2 = "script-with-attrs";';

    assert.strictEqual(children.length, 0, 'Parent element has no children before scriptlet is run');

    runScriptlet(name, [ROOT_SELECTOR, childTagName, attributesParam, textContent]);

    assert.strictEqual(children.length, 1, 'Script element was appended');

    const child = children[0];

    assert.strictEqual(child.tagName.toLowerCase(), childTagName, 'Tag name is set correctly');
    assert.strictEqual(child.getAttribute('type'), 'text/javascript', 'Type attribute is set correctly');
    assert.strictEqual(child.getAttribute('data-test'), 'value', 'Data attribute is set correctly');
    assert.strictEqual(child.textContent, textContent, 'Text content is set correctly');
    assert.strictEqual(window.scriptTestVar2, 'script-with-attrs', 'Script was executed');

    assert.strictEqual(window.hit, 'FIRED', 'hit fired');

    clearGlobalProps('scriptTestVar2');
});

test('trustedTypes.createScript is called for script textContent', (assert) => {
    if (!window.trustedTypes) {
        assert.expect(0);
        return;
    }

    const { children } = createRoot(ROOT_ID);

    const nativeCreatePolicy = window.trustedTypes.createPolicy.bind(window.trustedTypes);
    let createScriptCalled = false;
    let createScriptArg = null;

    window.trustedTypes.createPolicy = (name, rules) => {
        const wrappedRules = {
            ...rules,
            createScript: (input) => {
                createScriptCalled = true;
                createScriptArg = input;
                return rules.createScript ? rules.createScript(input) : input;
            },
        };
        return nativeCreatePolicy(name, wrappedRules);
    };

    const childTagName = 'script';
    const textContent = 'window.scriptTestVar3 = "trusted-types-verify";';

    runScriptlet(name, [ROOT_SELECTOR, childTagName, '', textContent]);

    assert.strictEqual(children.length, 1, 'Script element was appended');
    assert.true(createScriptCalled, 'trustedTypes createScript was called');
    assert.strictEqual(createScriptArg, textContent, 'createScript was called with correct textContent');
    assert.strictEqual(window.scriptTestVar3, 'trusted-types-verify', 'Script was executed');
    assert.strictEqual(window.hit, 'FIRED', 'hit fired');

    window.trustedTypes.createPolicy = nativeCreatePolicy;
    clearGlobalProps('scriptTestVar3');
});
