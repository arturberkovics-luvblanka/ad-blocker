import { hit } from '../helpers';
import { type Source } from './scriptlets';

/**
 * @scriptlet disable-newtab-links
 *
 * @description
 * Prevents opening new tabs and windows if there is `target` attribute in element.
 *
 * Related UBO scriptlet:
 * https://github.com/gorhill/uBlock/wiki/Resources-Library#disable-newtab-linksjs-
 *
 * ### Syntax
 *
 * ```adblock
 * example.org#%#//scriptlet('disable-newtab-links')
 * ```
 *
 * @added v1.0.4.
 */
export function disableNewtabLinks(source: Source) {
    document.addEventListener('click', (ev) => {
        let { target } = ev;
        while (target instanceof Element) {
            if (target.localName === 'a' && target.hasAttribute('target')) {
                ev.stopPropagation();
                ev.preventDefault();
                hit(source);
                break;
            }
            target = target.parentNode;
        }
    }, { capture: true });
}

export const disableNewtabLinksNames = [
    'disable-newtab-links',
    // aliases are needed for matching the related scriptlet converted into our syntax
    'disable-newtab-links.js',
    'ubo-disable-newtab-links.js',
    'ubo-disable-newtab-links',
];

// eslint-disable-next-line prefer-destructuring
disableNewtabLinks.primaryName = disableNewtabLinksNames[0];

disableNewtabLinks.injections = [
    hit,
];
